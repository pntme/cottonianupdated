<?php 
header("Access-Control-Allow-Origin: *");
mysql_connect("localhost","cottonian","m@12345");
mysql_select_db("cottonian");
?>